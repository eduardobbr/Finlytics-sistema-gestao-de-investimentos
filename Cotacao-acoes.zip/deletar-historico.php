<?php
include('includes/auth.php');
include('includes/db.php');

if (isset($_GET['id'])) {
  $id = intval($_GET['id']);

  $stmt = $conn->prepare("DELETE FROM historico WHERE id = ?");
  $stmt->bind_param("i", $id);

  if ($stmt->execute()) {
    $stmt->close();
    header("Location: historico.php");
    exit;
  } else {
    echo "Erro ao excluir item: " . $stmt->error;
  }
} else {
  echo "ID não especificado.";
}
