<?php
include('includes/auth.php');
include('includes/db.php');
$pagina_atual = basename($_SERVER['PHP_SELF']);
$sql = "SELECT * FROM acoes ORDER BY nome";
$resultado = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="UTF-8">
  <title>Tabela de Ações</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="/css/tabela-completa.css">
</head>

<body>

  <!-- HEADER -->
  <div class="bg-white border-bottom shadow-sm py-3 mb-4">
    <div class="container d-flex justify-content-between align-items-center flex-wrap gap-2">
      <h4 class="m-0">📈 Minhas Ações</h4>
      <div class="d-flex flex-wrap gap-2">
        <a href="dashboard.php"
          class="<?= 'btn btn-light fw-semibold' . ($pagina_atual == 'dashboard.php' ? ' active' : '') ?>">🏠
          Dashboard</a>
        <a href="adicionar.php"
          class="<?= 'btn btn-light fw-semibold' . ($pagina_atual == 'adicionar.php' ? ' active' : '') ?>">➕ Adicionar
          Ação</a>
        <a href="tabela-completa.php"
          class="<?= 'btn btn-light fw-semibold' . ($pagina_atual == 'tabela-completa.php' ? ' active' : '') ?>">📋
          Estoque</a>
        <a href="historico.php"
          class="<?= 'btn btn-light fw-semibold' . ($pagina_atual == 'historico.php' ? ' active' : '') ?>">📚 Histórico
          de Vendas</a>
        <a href="logout.php" class="btn btn-light fw-semibold">🚪 Sair</a>
      </div>
    </div>
  </div>

  <div class="container pb-5">
    <h2 class="mb-4 text-center">📋 Tabela de Ações</h2>

    <div class="row mb-4">
      <div class="col-md-6 offset-md-3">
        <input type="text" id="filtroAcao" class="form-control form-control-lg"
          placeholder="🔍 Filtrar por nome da ação...">
      </div>
    </div>

    <div class="table-responsive">
      <table class="table table-bordered text-center align-middle" id="tabelaAcoes">
        <thead class="table-dark">
          <tr>
            <th>Ativo</th>
            <th>Data de Compra</th>
            <th>Cotação Compra</th>
            <th>Quantidade</th>
            <th>Volume Financeiro</th>
            <th>Cotação Atual</th>
            <th>Volume Atual</th>
            <th>Lucro / Prejuízo</th>
            <th>Comissão Compra</th>
            <th>Probabilidade</th>
            <th>Ações</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($acao = $resultado->fetch_assoc()):
            $valorCompraTotal = $acao['cotacao_compra'] * $acao['quantidade'];
            $valorAtualTotal = $acao['cotacao_atual'] * $acao['quantidade'];
            $comissaoCompra = floatval($acao['comissao_compra']);

            $lucro = $valorAtualTotal - $valorCompraTotal - $comissaoCompra;

            $classe = $lucro > 0 ? 'linha-verde' : ($lucro < 0 ? 'linha-vermelha' : 'linha-azul');
            $seta = $acao['probabilidade'] == 'alta' ? '🔼' : ($acao['probabilidade'] == 'baixa' ? '🔽' : '');
            ?>
            <tr class="<?= $classe ?>">
              <td class="nome-acao"><strong><?= htmlspecialchars($acao['nome']) ?></strong></td>
              <td><?= date('d/m/Y', strtotime($acao['data_compra'])) ?></td>
              <td class="cotacao-compra">R$ <?= number_format($acao['cotacao_compra'], 2, ',', '.') ?></td>
              <td class="quantidade"><?= $acao['quantidade'] ?></td>
              <td class="volume-compra">R$ <?= number_format($valorCompraTotal, 2, ',', '.') ?></td>
              <td class="cotacao-atual">R$ <?= number_format($acao['cotacao_atual'], 2, ',', '.') ?></td>
              <td class="volume-atual">R$ <?= number_format($valorAtualTotal, 2, ',', '.') ?></td>
              <td class="lucro"><strong><?= ($lucro >= 0 ? '+' : '-') ?> R$
                  <?= number_format(abs($lucro), 2, ',', '.') ?></strong></td>
              <td>R$ <?= number_format($acao['comissao_compra'], 2, ',', '.') ?></td>
              <td><?= $seta ?></td>
              <td>
                <a href="editar.php?id=<?= $acao['id'] ?>" class="btn-sm-white" title="Editar"
                  data-bs-toggle="tooltip">✏️</a>
                <a href="deletar.php?id=<?= $acao['id'] ?>" class="btn-sm-white" title="Excluir" data-bs-toggle="tooltip"
                  onclick="return confirm('Deseja excluir esta ação?')">🗑️</a>
                <button
                  onclick="abrirModalVenda(<?= $acao['id'] ?>, '<?= htmlspecialchars($acao['nome']) ?>', <?= $acao['cotacao_compra'] ?>, <?= $acao['quantidade'] ?>)"
                  class="btn-sm-white" title="Vender" data-bs-toggle="tooltip">💸</button>
              </td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Modal de Venda -->
  <div class="modal fade" id="modalVendaGlobal" tabindex="-1" aria-labelledby="modalVendaLabel" aria-hidden="true">
    <div class="modal-dialog">
      <form method="post" action="vender.php" class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">💸 Registrar Venda</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="id_acao" id="vendaId">
          <input type="hidden" name="nome_acao" id="vendaNome">
          <input type="hidden" name="valor_compra" id="vendaCompra">
          <input type="hidden" name="quantidade_total" id="vendaQuantTotal">
          <div class="mb-3">
            <label class="form-label">Quantidade a vender</label>
            <input type="number" name="quantidade" class="form-control" required min="1" id="vendaQtd">
          </div>
          <div class="mb-3">
            <label class="form-label">Valor de venda</label>
            <input type="number" step="0.01" name="valor_venda" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">💸 Comissão de Venda</label>
            <input type="number" step="0.01" name="comissao_venda" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Data da venda</label>
            <input type="date" name="data_venda" class="form-control" required>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
          <button type="submit" class="btn btn-success">Confirmar Venda</button>
        </div>
      </form>
    </div>
  </div>

  <script>
    function abrirModalVenda(id, nome, valorCompra, quantidade) {
      const modal = new bootstrap.Modal(document.getElementById('modalVendaGlobal'));
      document.getElementById('vendaId').value = id;
      document.getElementById('vendaNome').value = nome;
      document.getElementById('vendaCompra').value = valorCompra;
      document.getElementById('vendaQuantTotal').value = quantidade;
      document.getElementById('vendaQtd').max = quantidade;
      modal.show();
    }

    document.getElementById('filtroAcao').addEventListener('keyup', function () {
      const filtro = this.value.toLowerCase();
      const linhas = document.querySelectorAll('#tabelaAcoes tbody tr');
      linhas.forEach((linha) => {
        const nome = linha.querySelector('.nome-acao').textContent.toLowerCase();
        linha.style.display = nome.includes(filtro) ? '' : 'none';
      });
    });

    const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    [...tooltipTriggerList].map(el => new bootstrap.Tooltip(el));

    async function atualizarCotacoes() {
      const linhas = document.querySelectorAll("#tabelaAcoes tbody tr");
      if (!linhas.length) return;

      const tickers = [...new Set(Array.from(linhas).map(l => l.querySelector(".nome-acao").textContent.trim().toUpperCase()))];
      const url = `https://brapi.dev/api/quote/${tickers.join(",")}?token=cHdzjZvh5uSen79Riga7vX`;

      try {
        const res = await fetch(url);
        const data = await res.json();
        if (!data.results) return;

        data.results.forEach(acao => {
          const preco = acao.regularMarketPrice;
          const nome = acao.symbol;
          const linha = [...linhas].find(l => l.querySelector(".nome-acao").textContent.trim().toUpperCase() === nome);
          if (!linha || !preco) return;

          const qtd = parseFloat(linha.querySelector(".quantidade").textContent);
          const compra = parseFloat(linha.querySelector(".cotacao-compra").textContent.replace('R$', '').replace('.', '').replace(',', '.'));
          const comissaoCompra = parseFloat(linha.querySelectorAll("td")[8].textContent.replace('R$', '').replace('.', '').replace(',', '.'));

          const totalAtual = preco * qtd;
          const totalCompra = compra * qtd;
          const lucro = totalAtual - totalCompra - comissaoCompra;  

          linha.querySelector(".cotacao-atual").textContent = `R$ ${preco.toFixed(2).replace('.', ',')}`;
          linha.querySelector(".volume-atual").textContent = `R$ ${totalAtual.toFixed(2).replace('.', ',')}`;
          linha.querySelector(".lucro").innerHTML = `<strong>${lucro >= 0 ? '+' : '-'} R$ ${Math.abs(lucro).toFixed(2).replace('.', ',')}</strong>`;
          linha.className = lucro > 0 ? 'linha-verde' : (lucro < 0 ? 'linha-vermelha' : 'linha-azul');
        });
      } catch (err) {
        console.error("Erro ao buscar cotações:", err);
      }
    }

    atualizarCotacoes();
    setInterval(atualizarCotacoes, 60000); // atualiza a cada 60 segundos
  </script>

</body>

</html>