<?php
if (!isset($_GET['ticker'])) {
  http_response_code(400);
  echo json_encode(['erro' => 'Ticker não informado']);
  exit;
}

$ticker = strtoupper(trim($_GET['ticker']));
$url = "https://brapi.dev/api/quote/{$ticker}?range=1d&interval=1d&fundamental=true";

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

$resposta = curl_exec($ch);

if ($resposta === false) {
  http_response_code(500);
  echo json_encode(['erro' => 'Erro na requisição à API']);
  exit;
}

header('Content-Type: application/json');
echo $resposta;
