<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include('includes/auth.php');
include('includes/db.php');

$sql = "SELECT * FROM acoes ORDER BY created_at DESC";
$resultado = $conn->query($sql);

$totalInvestido = 0;
$totalAtual = 0;
$labels = [];
$valoresCompra = [];
$valoresAtual = [];
$lucros = [];
$dados = [];

while ($acao = $resultado->fetch_assoc()) {
  $valorCompra = $acao['cotacao_compra'] * $acao['quantidade'];
  $valorAtual = $acao['cotacao_atual'] * $acao['quantidade'];
  $lucro = $valorAtual - $valorCompra;

  $totalInvestido += $valorCompra;
  $totalAtual += $valorAtual;

  $labels[] = $acao['nome'];
  $valoresCompra[] = $valorCompra;
  $valoresAtual[] = $valorAtual;
  $lucros[] = $lucro;
  $dados[] = $acao;
}

$resultadoGeral = $totalAtual - $totalInvestido;
$corResultado = $resultadoGeral >= 0 ? 'success' : 'danger';
?>

<?php
$pagina_atual = basename($_SERVER['PHP_SELF']);
?>


<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="UTF-8">
  <title>Dashboard - Minhas Ações</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <link rel="stylesheet" href="/css/dashboard.css">
</head>

<body>

  <!-- HEADER -->
  <div class="bg-white border-bottom shadow-sm py-3 mb-4">
    <div class="container d-flex justify-content-between align-items-center flex-wrap gap-2">
      <h4 class="m-0">📈 Minhas Ações</h4>
      <div class="d-flex flex-wrap gap-2">
        <a href="dashboard.php"
          class="<?= 'btn btn-light fw-semibold' . ($pagina_atual == 'dashboard.php' ? ' active' : '') ?>">🏠
          Dashboard</a>
        <a href="adicionar.php"
          class="<?= 'btn btn-light fw-semibold' . ($pagina_atual == 'adicionar.php' ? ' active' : '') ?>">➕ Adicionar
          Ação</a>
        <a href="tabela-completa.php"
          class="<?= 'btn btn-light fw-semibold' . ($pagina_atual == 'tabela-completa.php' ? ' active' : '') ?>">📋
          Estoque</a>
        <a href="historico.php"
          class="<?= 'btn btn-light fw-semibold' . ($pagina_atual == 'historico.php' ? ' active' : '') ?>">📚 Histórico
          de Vendas</a>
        <a href="logout.php" class="btn btn-light fw-semibold">🚪 Sair</a>
      </div>
    </div>
  </div>


  <div class="container pb-5">

    <!-- Cartões Resumo -->
    <div class="row g-3 mb-5">
      <div class="col-md-4">
        <div class="card shadow border-start border-5 border-success rounded-4">
          <div class="card-body d-flex justify-content-between align-items-center">
            <div>
              <h6 class="text-muted text-uppercase fw-bold mb-1">Investido</h6>
              <h4 class="fw-semibold text-success">R$ <?= number_format($totalInvestido, 2, ',', '.') ?></h4>
            </div>
            <div class="display-5 text-success">💰</div>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card shadow border-start border-5 border-info rounded-4">
          <div class="card-body d-flex justify-content-between align-items-center">
            <div>
              <h6 class="text-muted text-uppercase fw-bold mb-1">Valor Atual</h6>
              <h4 class="fw-semibold text-info">R$ <?= number_format($totalAtual, 2, ',', '.') ?></h4>
            </div>
            <div class="display-5 text-info">📊</div>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card shadow border-start border-5 border-<?= $corResultado ?> rounded-4">
          <div class="card-body d-flex justify-content-between align-items-center">
            <div>
              <h6 class="text-muted text-uppercase fw-bold mb-1">Resultado Geral</h6>
              <h4 class="fw-semibold text-<?= $corResultado ?>">
                <?= $resultadoGeral >= 0 ? '🟢' : '🔴' ?> R$ <?= number_format($resultadoGeral, 2, ',', '.') ?>
              </h4>
            </div>
            <div class="display-5 text-<?= $corResultado ?>">📈</div>
          </div>
        </div>
      </div>
    </div>

    <!-- Principais Ações -->
    <h5 class="mb-3">⭐ Principais Ações</h5>
    <div class="row g-4 mb-5">
      <?php
      usort($dados, function ($a, $b) {
        $valorA = $a['cotacao_compra'] * $a['quantidade'];
        $valorB = $b['cotacao_compra'] * $b['quantidade'];
        return $valorB <=> $valorA;
      });
      $principais = array_slice($dados, 0, 3);

      foreach ($principais as $acao):
        $ticker = htmlspecialchars($acao['nome']);
        $quantidade = floatval($acao['quantidade']);
        $valorCompra = $acao['cotacao_compra'] * $quantidade;
        $valorAtual = $acao['cotacao_atual'] * $quantidade;
        $comissaoCompra = floatval($acao['comissao_compra']);
        $lucro = $valorAtual - $valorCompra - $comissaoCompra;
        $classe = $lucro > 0 ? 'card-lucro' : ($lucro < 0 ? 'card-prejuizo' : 'card-neutro');
        ?>
        <div class="col-md-4">
          <div class="card <?= $classe ?> card-principal-acao shadow" data-ticker="<?= $ticker ?>"
            data-quantidade="<?= $quantidade ?>" data-compra="<?= $valorCompra ?>" data-comissao="<?= $comissaoCompra ?>">
            <div class="card-body text-center">
              <h4><?= $ticker ?></h4>
              <p>Compra: R$ <?= number_format($valorCompra, 2, ',', '.') ?></p>
              <p class="valor-atual">Atual: R$ <?= number_format($valorAtual, 2, ',', '.') ?></p>
              <p class="valor-lucro"><strong><?= $lucro >= 0 ? 'Lucro' : 'Prejuízo' ?>: R$
                  <?= number_format(abs($lucro), 2, ',', '.') ?></strong></p>
              <a href="tabela-completa.php" class="btn btn-light btn-sm mt-2">🔍 Detalhes da Ação</a>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>


    <!-- Gráfico Pizza -->
    <div class="card shadow-sm mb-5">
      <div class="card-body text-center">
        <h5 class="card-title mb-3">🥧 Distribuição da Carteira</h5>
        <div style="max-width: 400px; margin: 0 auto;">
          <canvas id="graficoPizza" height="220"></canvas>
        </div>
      </div>
    </div>


    <script>

      async function atualizarCotacoesPrincipaisCards() {
        const cards = document.querySelectorAll(".card-principal-acao");
        if (!cards.length) return;

        const tickers = Array.from(cards).map(card => card.getAttribute('data-ticker')).filter(Boolean);
        if (!tickers.length) return;

        try {
          const res = await fetch(`https://brapi.dev/api/quote/${tickers.join(",")}?token=cHdzjZvh5uSen79Riga7vX`);
          const data = await res.json();

          if (!data.results) return;

          data.results.forEach(acao => {
            const preco = acao.regularMarketPrice;
            const nome = acao.symbol;

            const card = document.querySelector(`.card-principal-acao[data-ticker="${nome}"]`);
            if (!card || !preco) return;

            const qtd = parseFloat(card.getAttribute('data-quantidade'));
            const valorCompra = parseFloat(card.getAttribute('data-compra'));
            const comissao = parseFloat(card.getAttribute('data-comissao'));

            const valorAtual = preco * qtd;
            const lucro = valorAtual - valorCompra - comissao;

            card.querySelector('.valor-atual').textContent = `Atual: R$ ${valorAtual.toFixed(2).replace('.', ',')}`;
            card.querySelector('.valor-lucro').innerHTML = `<strong>${lucro >= 0 ? 'Lucro' : 'Prejuízo'}: R$ ${Math.abs(lucro).toFixed(2).replace('.', ',')}</strong>`;

            card.classList.remove('card-lucro', 'card-prejuizo', 'card-neutro');
            card.classList.add(lucro > 0 ? 'card-lucro' : (lucro < 0 ? 'card-prejuizo' : 'card-neutro'));
          });

        } catch (err) {
          console.warn("Erro ao atualizar cards principais:", err);
        }
      }

      atualizarCotacoesPrincipaisCards();
      setInterval(atualizarCotacoesPrincipaisCards, 60000); // atualiza a cada 60s

      const ctxPizza = document.getElementById('graficoPizza').getContext('2d');
      new Chart(ctxPizza, {
        type: 'pie',
        data: {
          labels: <?= json_encode($labels) ?>,
          datasets: [{
            label: 'Investido',
            data: <?= json_encode($valoresCompra) ?>,
            backgroundColor: [
              '#42a5f5', '#66bb6a', '#ffa726', '#ef5350', '#ab47bc',
              '#26a69a', '#ff7043', '#8d6e63', '#26c6da', '#d4e157'
            ],
            borderColor: '#fff',
            borderWidth: 2
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: 'bottom',
              labels: {
                color: '#333',
                font: { size: 12 },
                padding: 10
              }
            },
            tooltip: {
              callbacks: {
                label: function (context) {
                  let label = context.label || '';
                  let value = context.parsed;
                  return `${label}: R$ ${value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`;
                }
              }
            }
          }
        }
      });
    </script>

</body>

</html>