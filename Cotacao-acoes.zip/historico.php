<?php
include('includes/auth.php');
include('includes/db.php');
$pagina_atual = basename($_SERVER['PHP_SELF']);

$sql = "SELECT * FROM historico ORDER BY data_venda DESC";
$resultado = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="UTF-8">
  <title>Histórico de Vendas</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="/css/historico.css">
</head>

<body>

  <!-- HEADER -->
  <div class="bg-white border-bottom shadow-sm py-3 mb-4">
    <div class="container d-flex justify-content-between align-items-center flex-wrap gap-2">
      <h4 class="m-0">📈 Minhas Ações</h4>
      <div class="d-flex flex-wrap gap-2">
        <a href="dashboard.php"
          class="<?= 'btn btn-light fw-semibold' . ($pagina_atual == 'dashboard.php' ? ' active' : '') ?>">🏠
          Dashboard</a>
        <a href="adicionar.php"
          class="<?= 'btn btn-light fw-semibold' . ($pagina_atual == 'adicionar.php' ? ' active' : '') ?>">➕ Adicionar
          Ação</a>
        <a href="tabela-completa.php"
          class="<?= 'btn btn-light fw-semibold' . ($pagina_atual == 'tabela-completa.php' ? ' active' : '') ?>">📋
          Estoque</a>
        <a href="historico.php"
          class="<?= 'btn btn-light fw-semibold' . ($pagina_atual == 'historico.php' ? ' active' : '') ?>">📚 Histórico
          de Vendas</a>
        <a href="logout.php" class="btn btn-light fw-semibold">🚪 Sair</a>
      </div>
    </div>
  </div>

  <!-- CONTEÚDO -->
  <div class="container pb-5">
    <h2 class="mb-4 text-center">📊 Histórico de Vendas de Ações</h2>

    <div class="table-responsive">
      <table class="table table-bordered text-center align-middle">
        <thead class="table-dark">
          <tr>
            <th>Ativo</th>
            <th>Compra</th>
            <th>Data Compra</th>
            <th>Venda</th>
            <th>Data Venda</th>
            <th>Quantidade</th>
            <th>Comissão de Venda</th>
            <th>Lucro / Prejuízo</th>
            <th>Ações</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($linha = $resultado->fetch_assoc()):
            $valor_compra = floatval($linha['valor_compra']);
            $valor_venda = floatval($linha['valor_venda']);
            $quantidade = intval($linha['quantidade']);
            $comissao_venda = floatval($linha['comissao_venda']);
            $comissao_compra = 0; // Se quiser futuramente armazenar isso também no histórico, pode incluir
            $lucro = ($valor_venda * $quantidade) - ($valor_compra * $quantidade) - $comissao_venda - $comissao_compra;
            $classe = $lucro > 0 ? 'linha-verde' : ($lucro < 0 ? 'linha-vermelha' : 'linha-azul');
            ?>
            <tr class="<?= $classe ?>">
              <td><strong><?= htmlspecialchars($linha['nome']) ?></strong></td>
              <td>R$ <?= number_format($linha['valor_compra'], 2, ',', '.') ?></td>
              <td><?= date('d/m/Y', strtotime($linha['data_compra'])) ?></td>
              <td>R$ <?= number_format($linha['valor_venda'], 2, ',', '.') ?></td>
              <td><?= date('d/m/Y', strtotime($linha['data_venda'])) ?></td>
              <td><?= $linha['quantidade'] ?></td>
              <td>R$ <?= number_format($linha['comissao_venda'], 2, ',', '.') ?></td>
              <td><strong>R$ <?= number_format($lucro, 2, ',', '.') ?></strong></td>
              <td>
                <a href="deletar-historico.php?id=<?= $linha['id'] ?>" class="btn-sm-white" title="Excluir"
                  data-bs-toggle="tooltip" onclick="return confirm('Deseja excluir este histórico?')">🗑️</a>
              </td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>

    <div class="text-center mt-4">
      <a href="dashboard.php" class="btn btn-outline-secondary btn-lg">⬅ Voltar para o Dashboard</a>
    </div>
  </div>

  <script>
    const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    [...tooltipTriggerList].map(el => new bootstrap.Tooltip(el));
  </script>

</body>

</html>