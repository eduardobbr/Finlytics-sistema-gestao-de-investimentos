<?php
include('includes/auth.php');
include('includes/db.php');
$pagina_atual = basename($_SERVER['PHP_SELF']);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $nome = strtoupper(trim($_POST['nome']));
  $cotacao_compra = floatval($_POST['cotacao_compra']);
  $cotacao_atual = floatval($_POST['cotacao_atual']);
  $quantidade = intval($_POST['quantidade']);
  $data_compra = $_POST['data_compra'];
  $comissao_compra = floatval($_POST['comissao_compra']);
  $probabilidade = $_POST['probabilidade'];

  $stmt = $conn->prepare("INSERT INTO acoes 
    (nome, data_compra, cotacao_compra, cotacao_atual, comissao_compra, quantidade, probabilidade) 
    VALUES (?, ?, ?, ?, ?, ?, ?)");
  $stmt->bind_param(
    "ssdddis",
    $nome,
    $data_compra,
    $cotacao_compra,
    $cotacao_atual,
    $comissao_compra,
    $quantidade,
    $probabilidade
  );


  if ($stmt->execute()) {
    header("Location: dashboard.php");
    exit();
  } else {
    $erro = "Erro ao salvar: " . $stmt->error;
  }
}

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="UTF-8">
  <title>Nova Ação</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="/css/adicionar.css">
</head>

<body>

  <!-- HEADER -->
  <div class="bg-white border-bottom shadow-sm py-3 mb-4">
    <div class="container d-flex justify-content-between align-items-center flex-wrap gap-2">
      <h4 class="m-0">📈 Minhas Ações</h4>
      <div class="d-flex flex-wrap gap-2">
        <a href="dashboard.php"
          class="<?= 'btn btn-light fw-semibold' . ($pagina_atual == 'dashboard.php' ? ' active' : '') ?>">🏠
          Dashboard</a>
        <a href="adicionar.php"
          class="<?= 'btn btn-light fw-semibold' . ($pagina_atual == 'adicionar.php' ? ' active' : '') ?>">➕ Adicionar
          Ação</a>
        <a href="tabela-completa.php"
          class="<?= 'btn btn-light fw-semibold' . ($pagina_atual == 'tabela-completa.php' ? ' active' : '') ?>">📋
          Estoque</a>
        <a href="historico.php"
          class="<?= 'btn btn-light fw-semibold' . ($pagina_atual == 'historico.php' ? ' active' : '') ?>">📚 Histórico
          de Vendas</a>
        <a href="logout.php" class="btn btn-light fw-semibold">🚪 Sair</a>
      </div>
    </div>
  </div>

  <!-- FORMULÁRIO -->
  <div class="container form-container">
    <div class="form-card">
      <h2 class="text-center mb-4">➕ Adicionar Nova Ação</h2>

      <?php if (isset($erro)): ?>
        <div class="alert alert-danger"><?= $erro ?></div>
      <?php endif; ?>

      <form method="post" novalidate>
        <div class="mb-3 position-relative">
          <label for="nome" class="form-label">💹 Nome da Ação (ex: PETR4)</label>
          <input type="text" name="nome" id="nome" class="form-control form-control-lg text-uppercase" required
            placeholder="Digite o nome da ação" autocomplete="off">
          <ul class="list-group w-100" id="lista-sugestoes" style="display:none; cursor:pointer;"></ul>
        </div>

        <div class="mb-3">
          <label for="data_compra" class="form-label">📅 Data da Compra</label>
          <input type="date" name="data_compra" id="data_compra" class="form-control form-control-lg" required>
        </div>

        <div class="row g-3">
          <div class="col-md-6">
            <label for="cotacao_compra" class="form-label">💵 Cotação de Compra</label>
            <input type="number" step="0.01" name="cotacao_compra" id="cotacao_compra"
              class="form-control form-control-lg" required>
          </div>
          <div class="col-md-6">
            <label for="cotacao_atual" class="form-label">📈 Cotação Atual</label>
            <input type="number" step="0.01" name="cotacao_atual" id="cotacao_atual"
              class="form-control form-control-lg" readonly placeholder="Preenchido automaticamente">
          </div>

        </div>

        <div class="row g-3 mt-1">
          <div class="col-md-6">
            <label for="comissao_compra" class="form-label">💸 Comissão de Compra (R$)</label>
            <input type="number" step="0.01" name="comissao_compra" id="comissao_compra"
              class="form-control form-control-lg" required>
          </div>
        </div>

        <div class="mt-3">
          <label for="quantidade" class="form-label">🔢 Quantidade de Ações</label>
          <input type="number" name="quantidade" id="quantidade" class="form-control form-control-lg" required
            placeholder="Ex: 100">
        </div>

        <div class="mt-3">
          <label for="probabilidade" class="form-label">📈 Seta de Probabilidade</label>
          <select name="probabilidade" id="probabilidade" class="form-select form-select-lg" required>
            <option value="" disabled selected>Selecione uma opção</option>
            <option value="alta">🔼 (Alta)</option>
            <option value="baixa">🔽 (Baixa)</option>
          </select>
        </div>

        <div class="mt-4 d-flex justify-content-between">
          <a href="dashboard.php" class="btn btn-outline-secondary btn-lg">⬅ Voltar</a>
          <button type="submit" class="btn btn-primary btn-lg btn-save">💾 Salvar Ação</button>
        </div>
      </form>
    </div>
  </div>

  <script>
    let todasAcoes = [];

    // Carrega lista de tickers da B3
    fetch("tickers-b3.json")
      .then(response => response.json())
      .then(data => {
        todasAcoes = data.results.map(item => item.ticker);
      });


    const campoNome = document.getElementById('nome');
    const lista = document.getElementById('lista-sugestoes');

    // Autocompletar
    campoNome.addEventListener('input', function () {
      const input = this.value.toUpperCase();
      lista.innerHTML = '';

      if (input.length < 2) {
        lista.style.display = 'none';
        document.getElementById('cotacao_atual').readOnly = true;
        document.getElementById('cotacao_atual').value = '';
        return;
      }

      const sugestoes = todasAcoes.filter(t => t.includes(input)).slice(0, 10);
      if (sugestoes.length === 0) {
        lista.style.display = 'none';
        document.getElementById('cotacao_atual').readOnly = false;
        return;
      } else {
        document.getElementById('cotacao_atual').readOnly = true;
      }

      sugestoes.forEach(ticker => {
        const li = document.createElement('li');
        li.classList.add('list-group-item', 'list-group-item-action');
        li.textContent = ticker;
        li.onclick = function () {
          campoNome.value = ticker;
          lista.style.display = 'none';
          buscarCotacao(ticker);
          document.getElementById('cotacao_atual').readOnly = true;
        };
        lista.appendChild(li);
      });

      lista.style.display = 'block';
    });


    // Buscar cotação atual via PHP proxy
    function buscarCotacao(ticker) {
      fetch(`https://brapi.dev/api/quote/${ticker}?token=cHdzjZvh5uSen79Riga7vX`)
        .then(res => res.json())
        .then(data => {
          const preco = data.results?.[0]?.regularMarketPrice;
          if (preco) {
            document.getElementById('cotacao_atual').value = preco;
          } else {
            alert("Cotação não encontrada para " + ticker);
          }
        })
        .catch(() => {
          alert("Erro ao buscar cotação.");
        });
    }


  </script>



</body>

</html>