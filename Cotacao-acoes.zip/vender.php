<?php
include('includes/auth.php');
include('includes/db.php');

// Ativa exibição de erros
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $id_acao = intval($_POST['id_acao']);
  $nome = trim($_POST['nome_acao']);
  $valor_compra = floatval($_POST['valor_compra']);
  $quantidade_total = intval($_POST['quantidade_total']);
  $quantidade_vendida = intval($_POST['quantidade']);
  $valor_venda = floatval($_POST['valor_venda']);
  $comissao_venda = floatval($_POST['comissao_venda']);
  $data_venda = date('Y-m-d', strtotime($_POST['data_venda']));

  // Recupera dados da ação
  $stmt = $conn->prepare("SELECT * FROM acoes WHERE id = ?");
  $stmt->bind_param("i", $id_acao);
  $stmt->execute();
  $resultado = $stmt->get_result();
  $acao = $resultado->fetch_assoc();
  $stmt->close();

  if (!$acao) {
    die('Ação não encontrada.');
  }

  // Corrige a data de compra
  $data_raw = trim($acao['data_compra']);
  if (preg_match('/^\d{4}$/', $data_raw)) {
    $data_compra = $data_raw . '-01-01';
  } elseif (preg_match('/^\d{4}-\d{2}$/', $data_raw)) {
    $data_compra = $data_raw . '-01';
  } elseif (strtotime($data_raw) === false || strlen($data_raw) < 6) {
    $data_compra = date('Y-m-d');
  } else {
    $data_compra = date('Y-m-d', strtotime($data_raw));
  }

  $comissao_compra = floatval($acao['comissao_compra']);

  // Cálculo do lucro considerando comissão de compra e venda
  $lucro = (($valor_venda * $quantidade_vendida) - ($valor_compra * $quantidade_vendida)) - $comissao_compra - $comissao_venda;

  // Insere no histórico
  $stmt = $conn->prepare("INSERT INTO historico (nome, valor_compra, data_compra, valor_venda, data_venda, quantidade, comissao_venda, lucro) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
  $stmt->bind_param("sdsdsidd", $nome, $valor_compra, $data_compra, $valor_venda, $data_venda, $quantidade_vendida, $comissao_venda, $lucro);
  $stmt->execute();
  $stmt->close();

  // Atualiza ou remove da tabela de ações
  if ($quantidade_vendida >= $quantidade_total) {
    $stmt = $conn->prepare("DELETE FROM acoes WHERE id = ?");
    $stmt->bind_param("i", $id_acao);
  } else {
    $nova_quantidade = $quantidade_total - $quantidade_vendida;
    $stmt = $conn->prepare("UPDATE acoes SET quantidade = ? WHERE id = ?");
    $stmt->bind_param("ii", $nova_quantidade, $id_acao);
  }
  $stmt->execute();
  $stmt->close();

  header("Location: tabela-completa.php");
  exit;
} else {
  header("Location: tabela-completa.php");
  exit;
}
