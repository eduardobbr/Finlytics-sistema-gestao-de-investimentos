<?php
include('includes/auth.php');
include('includes/db.php');

if (!isset($_GET['id'])) {
  header("Location: dashboard.php");
  exit();
}

$id = intval($_GET['id']);
$stmt = $conn->prepare("SELECT * FROM acoes WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
  echo "<div class='alert alert-danger'>Ação não encontrada.</div>";
  exit();
}

$acao = $result->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $nome = strtoupper(trim($_POST['nome']));
  $cotacao_compra = floatval($_POST['cotacao_compra']);
  $cotacao_atual = floatval($_POST['cotacao_atual']);
  $quantidade = intval($_POST['quantidade']);
  $anotacoes = trim($_POST['anotacoes']);
  $data_compra = $_POST['data_compra'];
  $comissao_compra = floatval($_POST['comissao_compra']);
  $comissao_venda = floatval($_POST['comissao_venda']);
  $probabilidade = $_POST['probabilidade'];

  $stmt = $conn->prepare("UPDATE acoes SET nome=?, cotacao_compra=?, cotacao_atual=?, quantidade=?, anotacoes=?, data_compra=?, comissao_compra=?, comissao_venda=?, probabilidade=? WHERE id=?");
  $stmt->bind_param("sddissddsi", $nome, $cotacao_compra, $cotacao_atual, $quantidade, $anotacoes, $data_compra, $comissao_compra, $comissao_venda, $probabilidade, $id);

  if ($stmt->execute()) {
    header("Location: dashboard.php");
    exit();
  } else {
    $erro = "Erro ao atualizar: " . $stmt->error;
  }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Editar Ação</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #f1f5f9; }
    .form-container { max-width: 700px; margin: 30px auto; }
    .form-card {
      border-radius: 16px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.12);
      background: white;
      padding: 40px;
    }
    .form-card h2 { font-weight: bold; color: #0d6efd; }
    .form-card label { font-weight: 500; }
    .btn-save { font-size: 1.1rem; }
  </style>
</head>
<body>

<div class="bg-white border-bottom shadow-sm py-3 mb-4">
  <div class="container d-flex justify-content-between align-items-center flex-wrap gap-2">
    <h4 class="m-0">📈 Minhas Ações</h4>
    <div class="d-flex flex-wrap gap-2">
      <a href="dashboard.php" class="btn btn-light fw-semibold">🏠 Dashboard</a>
      <a href="adicionar.php" class="btn btn-light fw-semibold">➕ Nova Ação</a>
      <a href="tabela-completa.php" class="btn btn-light fw-semibold">📋 Ver Tabela</a>
      <a href="historico.php" class="btn btn-light fw-semibold">📚 Ver Histórico</a>
      <a href="logout.php" class="btn btn-light fw-semibold">🚪 Sair</a>
    </div>
  </div>
</div>

<div class="container form-container">
  <div class="form-card">
    <h2 class="text-center mb-4">✏️ Editar Ação</h2>

    <?php if (isset($erro)): ?>
      <div class="alert alert-danger"><?= $erro ?></div>
    <?php endif; ?>

    <form method="post">
      <div class="mb-3">
        <label for="nome" class="form-label">💹 Nome da Ação (ex: PETR4)</label>
        <input type="text" name="nome" id="nome" class="form-control form-control-lg text-uppercase" required maxlength="10" value="<?= htmlspecialchars($acao['nome']) ?>">
      </div>

      <div class="row g-3">
        <div class="col-md-6">
          <label for="cotacao_compra" class="form-label">💵 Cotação de Compra</label>
          <input type="number" step="0.01" name="cotacao_compra" id="cotacao_compra" class="form-control form-control-lg" required value="<?= $acao['cotacao_compra'] ?>">
        </div>
        <div class="col-md-6">
          <label for="cotacao_atual" class="form-label">📈 Cotação Atual</label>
          <input type="number" step="0.01" name="cotacao_atual" id="cotacao_atual" class="form-control form-control-lg" required value="<?= $acao['cotacao_atual'] ?>">
        </div>
      </div>

      <div class="row g-3 mt-3">
        <div class="col-md-6">
          <label for="quantidade" class="form-label">🔢 Quantidade de Ações</label>
          <input type="number" name="quantidade" id="quantidade" class="form-control form-control-lg" required value="<?= $acao['quantidade'] ?>">
        </div>
        <div class="col-md-6">
          <label for="data_compra" class="form-label">📅 Data da Compra</label>
          <input type="datetime-local" name="data_compra" id="data_compra" class="form-control form-control-lg" value="<?= date('Y-m-d\TH:i', strtotime($acao['data_compra'])) ?>">
        </div>
      </div>

      <div class="row g-3 mt-3">
        <div class="col-md-6">
          <label for="comissao_compra" class="form-label">💸 Comissão de Compra</label>
          <input type="number" step="0.01" name="comissao_compra" id="comissao_compra" class="form-control form-control-lg" value="<?= $acao['comissao_compra'] ?>">
        </div>
        <div class="col-md-6">
          <label for="comissao_venda" class="form-label">💸 Comissão de Venda</label>
          <input type="number" step="0.01" name="comissao_venda" id="comissao_venda" class="form-control form-control-lg" value="<?= $acao['comissao_venda'] ?>">
        </div>
      </div>

      <div class="mt-3">
        <label for="probabilidade" class="form-label">📊 Seta de Probabilidade</label>
        <select name="probabilidade" id="probabilidade" class="form-select form-select-lg">
          <option value="alta" <?= $acao['probabilidade'] == 'alta' ? 'selected' : '' ?>>🔼 Alta (para cima)</option>
          <option value="baixa" <?= $acao['probabilidade'] == 'baixa' ? 'selected' : '' ?>>🔽 Baixa (para baixo)</option>
        </select>
      </div>

      <div class="mt-3">
        <label for="anotacoes" class="form-label">📝 Anotações (opcional)</label>
        <textarea name="anotacoes" id="anotacoes" class="form-control form-control-lg" rows="4"><?= htmlspecialchars($acao['anotacoes']) ?></textarea>
      </div>

      <div class="mt-4 d-flex justify-content-between">
        <a href="tabela-completa.php" class="btn btn-outline-secondary btn-lg">⬅ Cancelar</a>
        <button type="submit" class="btn btn-primary btn-lg btn-save">💾 Salvar Alterações</button>
      </div>
    </form>
  </div>
</div>

</body>
</html>
