<?php
include('includes/auth.php');
include('includes/db.php');
$pagina_atual = basename($_SERVER['PHP_SELF']);

$sql = "SELECT * FROM acoes ORDER BY nome";
$resultado = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Tabela de Ações</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    body { background-color: #ffffff; }
    .linha-verde { background-color: #2e7d32 !important; color: white; }
    .linha-vermelha { background-color: #c62828 !important; color: white; }
    .linha-azul { background-color: #1565c0 !important; color: white; }
    .btn-sm-white {
      background-color: rgba(255,255,255,0.9);
      color: #000;
      border: none;
      padding: 6px 10px;
      border-radius: 4px;
      font-weight: bold;
      margin: 0 2px;
    }
    .btn-sm-white:hover { background-color: #f0f0f0; }
    .btn.active {
      background-color: #0d6efd;
      color: white !important;
      border-color: #0d6efd;
    }
  </style>
</head>
<body>

<div class="bg-white border-bottom shadow-sm py-3 mb-4">
  <div class="container d-flex justify-content-between align-items-center flex-wrap gap-2">
    <h4 class="m-0">📈 Minhas Ações</h4>
    <div class="d-flex flex-wrap gap-2">
      <a href="dashboard.php" class="<?= 'btn btn-light fw-semibold' . ($pagina_atual == 'dashboard.php' ? ' active' : '') ?>">🏠 Dashboard</a>
      <a href="adicionar.php" class="<?= 'btn btn-light fw-semibold' . ($pagina_atual == 'adicionar.php' ? ' active' : '') ?>">➕ Nova Ação</a>
      <a href="tabela-completa.php" class="<?= 'btn btn-light fw-semibold' . ($pagina_atual == 'tabela-completa.php' ? ' active' : '') ?>">📋 Ver Tabela</a>
      <a href="historico.php" class="<?= 'btn btn-light fw-semibold' . ($pagina_atual == 'historico.php' ? ' active' : '') ?>">📚 Ver Histórico</a>
      <a href="logout.php" class="btn btn-light fw-semibold">🚪 Sair</a>
    </div>
  </div>
</div>

<div class="container pb-5">
  <h2 class="mb-4 text-center">📋 Tabela de Ações</h2>

  <!-- Filtro de busca -->
  <div class="row mb-4">
    <div class="col-md-6 offset-md-3">
      <input type="text" id="filtroAcao" class="form-control form-control-lg" placeholder="🔍 Filtrar por nome da ação...">
    </div>
  </div>

  <div class="table-responsive">
    <table class="table table-bordered text-center align-middle" id="tabelaAcoes">
      <thead class="table-dark">
        <tr>
          <th>Ativo</th>
          <th>Compra</th>
          <th>Atual</th>
          <th>Qtd</th>
          <th>Lucro / Prejuízo</th>
          <th>Detalhes</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($acao = $resultado->fetch_assoc()):
          $valorCompra = $acao['cotacao_compra'] * $acao['quantidade'];
          $valorAtual = $acao['cotacao_atual'] * $acao['quantidade'];
          $lucro = $valorAtual - $valorCompra;
          $classe = $lucro > 0 ? 'linha-verde' : ($lucro < 0 ? 'linha-vermelha' : 'linha-azul');
          $seta = $acao['probabilidade'] == 'alta' ? '🔼' : ($acao['probabilidade'] == 'baixa' ? '🔽' : '');
        ?>
        <tr class="<?= $classe ?>">
          <td class="nome-acao"><strong><?= htmlspecialchars($acao['nome']) ?></strong></td>
          <td>R$ <?= number_format($acao['cotacao_compra'], 2, ',', '.') ?></td>
          <td>R$ <?= number_format($acao['cotacao_atual'], 2, ',', '.') ?></td>
          <td><?= $acao['quantidade'] ?></td>
          <td><strong><?= ($lucro >= 0 ? '+' : '-') ?> R$ <?= number_format(abs($lucro), 2, ',', '.') ?></strong></td>
          <td>
            <button 
              class="btn-sm-white" 
              data-bs-toggle="modal" 
              data-bs-target="#modalDetalhes<?= $acao['id'] ?>">
              🔍
            </button>

            <!-- Modal -->
            <div class="modal fade" id="modalDetalhes<?= $acao['id'] ?>" tabindex="-1" aria-labelledby="modalLabel<?= $acao['id'] ?>" aria-hidden="true">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="modalLabel<?= $acao['id'] ?>">📝 Detalhes da Ação - <?= htmlspecialchars($acao['nome']) ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                  </div>
                  <div class="modal-body text-start">
                    <p><strong>Nome:</strong> <?= htmlspecialchars($acao['nome']) ?></p>
                    <p><strong>Data de Compra:</strong> <?= date('d/m/Y H:i', strtotime($acao['data_compra'])) ?></p>
                    <p><strong>Compra:</strong> R$ <?= number_format($acao['cotacao_compra'], 2, ',', '.') ?></p>
                    <p><strong>Atual:</strong> R$ <?= number_format($acao['cotacao_atual'], 2, ',', '.') ?></p>
                    <p><strong>Quantidade:</strong> <?= $acao['quantidade'] ?></p>
                    <p><strong>Comissão de Compra:</strong> R$ <?= number_format($acao['comissao_compra'], 2, ',', '.') ?></p>
                    <p><strong>Comissão de Venda:</strong> R$ <?= number_format($acao['comissao_venda'], 2, ',', '.') ?></p>
                    <p><strong>Probabilidade:</strong> <?= $seta ?></p>
                    <p><strong>Lucro / Prejuízo:</strong> <?= ($lucro >= 0 ? '+' : '-') ?> R$ <?= number_format(abs($lucro), 2, ',', '.') ?></p>
                    <?php if (!empty($acao['anotacoes'])): ?>
                      <p><strong>Anotações:</strong> <?= nl2br(htmlspecialchars($acao['anotacoes'])) ?></p>
                    <?php endif; ?>
                  </div>
                  <div class="modal-footer">
                    <a href="editar.php?id=<?= $acao['id'] ?>" class="btn-sm-white" title="Editar" data-bs-toggle="tooltip"><span title="Editar">✏️</span></a>
                    <a href="deletar.php?id=<?= $acao['id'] ?>" class="btn-sm-white" title="Excluir" data-bs-toggle="tooltip" onclick="return confirm('Deseja excluir esta ação?')"><span title="Excluir">🗑️</span></a>
                    <button onclick="abrirModalVenda(<?= $acao['id'] ?>, '<?= htmlspecialchars($acao['nome']) ?>', <?= $acao['cotacao_compra'] ?>, <?= $acao['quantidade'] ?>)" class="btn-sm-white" title="Vender" data-bs-toggle="tooltip"><span title="Vender">💸</span></button>
                  </div>
                </div>
              </div>
            </div>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>

<script>
function abrirModalVenda(id, nome, valorCompra, quantidade) {
  alert("Abrir lógica de venda para: " + nome);
}

const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
[...tooltipTriggerList].map(el => new bootstrap.Tooltip(el));

document.getElementById('filtroAcao').addEventListener('keyup', function () {
  const filtro = this.value.toLowerCase();
  const linhas = document.querySelectorAll('#tabelaAcoes tbody tr');
  linhas.forEach((linha) => {
    const nome = linha.querySelector('.nome-acao').textContent.toLowerCase();
    linha.style.display = nome.includes(filtro) ? '' : 'none';
  });
});
</script>

</body>
</html>
