<?php
include('includes/db.php');

// Verifica se todos os campos foram enviados
if (
  !isset($_POST['id_acao'], $_POST['nome_acao'], $_POST['valor_compra'],
           $_POST['quantidade'], $_POST['valor_venda'], $_POST['data_venda'])
) {
  echo "Erro: campos obrigatórios ausentes.";
  exit();
}

$id = intval($_POST['id_acao']);
$nome = $_POST['nome_acao'];
$valor_compra = floatval($_POST['valor_compra']);
$quantidade_vendida = intval($_POST['quantidade']);
$valor_venda = floatval($_POST['valor_venda']);
$data_venda = $_POST['data_venda'];

// Busca ação original
$sql = "SELECT * FROM acoes WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows === 0) {
  echo "Erro: ação não encontrada.";
  exit();
}

$acao = $res->fetch_assoc();
$quantidade_total = $acao['quantidade'];
$data_compra = $acao['created_at'] ?? date("Y-m-d H:i:s");

// Valida quantidade
if ($quantidade_vendida > $quantidade_total || $quantidade_vendida <= 0) {
  echo "Erro: quantidade inválida.";
  exit();
}

// Calcula lucro ou prejuízo
$lucro = ($valor_venda - $valor_compra) * $quantidade_vendida;

// Atualiza ou remove da tabela de ações
if ($quantidade_total > $quantidade_vendida) {
  $nova_qtd = $quantidade_total - $quantidade_vendida;
  $update = $conn->prepare("UPDATE acoes SET quantidade=? WHERE id=?");
  $update->bind_param("ii", $nova_qtd, $id);
  $update->execute();
} else {
  $delete = $conn->prepare("DELETE FROM acoes WHERE id=?");
  $delete->bind_param("i", $id);
  $delete->execute();
}

// Insere no histórico
$insert = $conn->prepare("INSERT INTO historico (nome, valor_compra, data_compra, valor_venda, data_venda, quantidade, lucro) VALUES (?, ?, ?, ?, ?, ?, ?)");
$insert->bind_param("sdddsid", $nome, $valor_compra, $data_compra, $valor_venda, $data_venda, $quantidade_vendida, $lucro);
$success = $insert->execute();

// Redireciona ou mostra erro
if ($success) {
  header("Location: tabela-completa.php?sucesso=1");
  exit();
} else {
  echo "Erro ao salvar no histórico: " . $insert->error;
  exit();
}
