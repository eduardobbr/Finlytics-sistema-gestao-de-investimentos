<?php
include('includes/auth.php');
include('includes/db.php');
$pagina_atual = basename($_SERVER['PHP_SELF']);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $nome = strtoupper(trim($_POST['nome']));
  $cotacao_compra = floatval($_POST['cotacao_compra']);
  $cotacao_atual = floatval($_POST['cotacao_atual']);
  $quantidade = intval($_POST['quantidade']);
  $anotacoes = trim($_POST['anotacoes']);
  $data_compra = $_POST['data_compra'];
  $comissao_compra = floatval($_POST['comissao_compra']);
  $comissao_venda = floatval($_POST['comissao_venda']);
  $probabilidade = $_POST['probabilidade'];

  $stmt = $conn->prepare("INSERT INTO acoes 
    (nome, data_compra, cotacao_compra, cotacao_atual, comissao_compra, comissao_venda, quantidade, probabilidade, anotacoes) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
  $stmt->bind_param("ssddddiss", 
    $nome, $data_compra, $cotacao_compra, $cotacao_atual, $comissao_compra, $comissao_venda, $quantidade, $probabilidade, $anotacoes);

  if ($stmt->execute()) {
    header("Location: dashboard.php");
    exit();
  } else {
    $erro = "Erro ao salvar: " . $stmt->error;
  }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Nova Ação</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background: #f1f5f9; }
    .form-container { max-width: 700px; margin: 50px auto; }
    .form-card {
      border-radius: 16px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.12);
      background: white;
      padding: 40px;
    }
    .form-card h2 { font-weight: bold; color: #0d6efd; }
    .form-card label { font-weight: 500; }
    .btn-save { font-size: 1.1rem; }
    .btn.active {
      background-color: #0d6efd;
      color: white !important;
      border-color: #0d6efd;
    }
  </style>
</head>
<body>

<!-- HEADER -->
<div class="bg-white border-bottom shadow-sm py-3 mb-4">
  <div class="container d-flex justify-content-between align-items-center flex-wrap gap-2">
    <h4 class="m-0">📈 Minhas Ações</h4>
    <div class="d-flex flex-wrap gap-2">
      <a href="dashboard.php" class="<?= 'btn btn-light fw-semibold' . ($pagina_atual == 'dashboard.php' ? ' active' : '') ?>">🏠 Dashboard</a>
      <a href="adicionar.php" class="<?= 'btn btn-light fw-semibold' . ($pagina_atual == 'adicionar.php' ? ' active' : '') ?>">➕ Nova Ação</a>
      <a href="tabela-completa.php" class="<?= 'btn btn-light fw-semibold' . ($pagina_atual == 'tabela-completa.php' ? ' active' : '') ?>">📋 Ver Tabela</a>
      <a href="historico.php" class="<?= 'btn btn-light fw-semibold' . ($pagina_atual == 'historico.php' ? ' active' : '') ?>">📚 Ver Histórico</a>
      <a href="logout.php" class="btn btn-light fw-semibold">🚪 Sair</a>
    </div>
  </div>
</div>

<!-- FORMULÁRIO -->
<div class="container form-container">
  <div class="form-card">
    <h2 class="text-center mb-4">➕ Adicionar Nova Ação</h2>

    <?php if (isset($erro)): ?>
      <div class="alert alert-danger"><?= $erro ?></div>
    <?php endif; ?>

    <form method="post" novalidate>
      <div class="mb-3">
        <label for="nome" class="form-label">💹 Nome da Ação (ex: PETR4)</label>
        <input type="text" name="nome" id="nome" class="form-control form-control-lg text-uppercase" required maxlength="10" placeholder="Digite o nome do ativo">
      </div>

      <div class="mb-3">
        <label for="data_compra" class="form-label">📅 Data da Compra</label>
        <input type="datetime-local" name="data_compra" id="data_compra" class="form-control form-control-lg" required>
      </div>

      <div class="row g-3">
        <div class="col-md-6">
          <label for="cotacao_compra" class="form-label">💵 Cotação de Compra</label>
          <input type="number" step="0.01" name="cotacao_compra" id="cotacao_compra" class="form-control form-control-lg" required>
        </div>
        <div class="col-md-6">
          <label for="cotacao_atual" class="form-label">📈 Cotação Atual</label>
          <input type="number" step="0.01" name="cotacao_atual" id="cotacao_atual" class="form-control form-control-lg" required>
        </div>
      </div>

      <div class="row g-3 mt-1">
        <div class="col-md-6">
          <label for="comissao_compra" class="form-label">💸 Comissão de Compra (R$)</label>
          <input type="number" step="0.01" name="comissao_compra" id="comissao_compra" class="form-control form-control-lg" required>
        </div>
        <div class="col-md-6">
          <label for="comissao_venda" class="form-label">💸 Comissão de Venda (R$)</label>
          <input type="number" step="0.01" name="comissao_venda" id="comissao_venda" class="form-control form-control-lg" required>
        </div>
      </div>

      <div class="mt-3">
        <label for="quantidade" class="form-label">🔢 Quantidade de Ações</label>
        <input type="number" name="quantidade" id="quantidade" class="form-control form-control-lg" required placeholder="Ex: 100">
      </div>

      <div class="mt-3">
        <label for="probabilidade" class="form-label">📈 Seta de Probabilidade</label>
        <select name="probabilidade" id="probabilidade" class="form-select form-select-lg" required>
          <option value="" disabled selected>Selecione uma opção</option>
          <option value="alta">🔼 (Alta)</option>
          <option value="baixa">🔽 (Baixa)</option>
        </select>
      </div>

      <div class="mt-3">
        <label for="anotacoes" class="form-label">📝 Anotações (opcional)</label>
        <textarea name="anotacoes" id="anotacoes" class="form-control form-control-lg" rows="4" placeholder="Escreva algo sobre essa ação..."></textarea>
      </div>

      <div class="mt-4 d-flex justify-content-between">
        <a href="dashboard.php" class="btn btn-outline-secondary btn-lg">⬅ Voltar</a>
        <button type="submit" class="btn btn-primary btn-lg btn-save">💾 Salvar Ação</button>
      </div>
    </form>
  </div>
</div>

</body>
</html>
