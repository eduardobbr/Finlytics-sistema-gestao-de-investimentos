<?php
include('includes/auth.php');
include('includes/db.php');
$pagina_atual = basename($_SERVER['PHP_SELF']);

$sql = "SELECT * FROM historico ORDER BY data_venda DESC";
$resultado = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Histórico de Vendas</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    body { background-color: #ffffff; }
    .linha-verde { background-color: #2e7d32 !important; color: white; }
    .linha-vermelha { background-color: #c62828 !important; color: white; }
    .linha-azul { background-color: #1565c0 !important; color: white; }
    .table th, .table td { vertical-align: middle; }
    .btn.active {
      background-color: #0d6efd;
      color: white !important;
      border-color: #0d6efd;
    }
  </style>
</head>
<body>

<!-- HEADER -->
<div class="bg-white border-bottom shadow-sm py-3 mb-4">
  <div class="container d-flex justify-content-between align-items-center flex-wrap gap-2">
    <h4 class="m-0">📈 Minhas Ações</h4>
    <div class="d-flex flex-wrap gap-2">
      <a href="dashboard.php" class="<?= 'btn btn-light fw-semibold' . ($pagina_atual == 'dashboard.php' ? ' active' : '') ?>">🏠 Dashboard</a>
      <a href="adicionar.php" class="<?= 'btn btn-light fw-semibold' . ($pagina_atual == 'adicionar.php' ? ' active' : '') ?>">➕ Nova Ação</a>
      <a href="tabela-completa.php" class="<?= 'btn btn-light fw-semibold' . ($pagina_atual == 'tabela-completa.php' ? ' active' : '') ?>">📋 Ver Tabela</a>
      <a href="historico.php" class="<?= 'btn btn-light fw-semibold' . ($pagina_atual == 'historico.php' ? ' active' : '') ?>">📚 Ver Histórico</a>
      <a href="logout.php" class="btn btn-light fw-semibold">🚪 Sair</a>
    </div>
  </div>
</div>

<!-- CONTEÚDO -->
<div class="container pb-5">
  <h2 class="mb-4 text-center">📊 Histórico de Vendas de Ações</h2>

  <div class="table-responsive">
    <table class="table table-bordered text-center align-middle">
      <thead class="table-dark">
        <tr>
          <th>Ativo</th>
          <th>Compra</th>
          <th>Data Compra</th>
          <th>Venda</th>
          <th>Data Venda</th>
          <th>Quantidade</th>
          <th>Lucro / Prejuízo</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($linha = $resultado->fetch_assoc()):
          $lucro = $linha['lucro'];
          $classe = $lucro > 0 ? 'linha-verde' : ($lucro < 0 ? 'linha-vermelha' : 'linha-azul');
        ?>
        <tr class="<?= $classe ?>">
          <td><strong><?= htmlspecialchars($linha['nome']) ?></strong></td>
          <td>R$ <?= number_format($linha['valor_compra'], 2, ',', '.') ?></td>
          <td><?= date('d/m/Y H:i', strtotime($linha['data_compra'])) ?></td>
          <td>R$ <?= number_format($linha['valor_venda'], 2, ',', '.') ?></td>
          <td><?= date('d/m/Y H:i', strtotime($linha['data_venda'])) ?></td>
          <td><?= $linha['quantidade'] ?></td>
          <td><strong>R$ <?= number_format($lucro, 2, ',', '.') ?></strong></td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>

  <div class="text-center mt-4">
    <a href="dashboard.php" class="btn btn-outline-secondary btn-lg">⬅ Voltar para o Dashboard</a>
  </div>
</div>

</body>
</html>
