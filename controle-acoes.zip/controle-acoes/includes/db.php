<?php
$host = "127.0.0.1";
$usuario = "root";
$senha = ""; // ou sua senha se tiver definido
$banco = "controle_acoes";
$porta = 3306;

$conn = new mysqli($host, $usuario, $senha, $banco, $porta);

if ($conn->connect_error) {
  die("Erro ao conectar com o banco de dados: " . $conn->connect_error);
}
?>
