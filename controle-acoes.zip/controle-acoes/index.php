<?php
session_start();

// Configuração de login simples
$usuario = "admin";
$senha = "123456";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $login = $_POST["login"];
  $senha_input = $_POST["senha"];

  if ($login === $usuario && $senha_input === $senha) {
    $_SESSION["logado"] = true;
    header("Location: dashboard.php");
    exit();
  } else {
    $erro = "Usuário ou senha incorretos.";
  }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Login - Controle de Ações</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f1f5f9;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
    }
    .card-login {
      max-width: 400px;
      width: 100%;
      padding: 30px;
      border-radius: 16px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
      background-color: white;
    }
    .card-login h2 {
      color: #0d6efd;
      font-weight: bold;
      margin-bottom: 25px;
    }
    .form-control::placeholder {
      font-size: 0.95rem;
    }
  </style>
</head>
<body>

<div class="card-login">
  <h2 class="text-center">🔐 Acesso ao Sistema</h2>

  <?php if (isset($erro)): ?>
    <div class="alert alert-danger"><?= $erro ?></div>
  <?php endif; ?>

  <form method="post" autocomplete="off">
    <div class="mb-3">
      <label class="form-label">Usuário</label>
      <input type="text" name="login" class="form-control form-control-lg" required placeholder="Digite seu login">
    </div>

    <div class="mb-3">
      <label class="form-label">Senha</label>
      <input type="password" name="senha" class="form-control form-control-lg" required placeholder="Digite sua senha">
    </div>

    <div class="d-grid">
      <button type="submit" class="btn btn-primary btn-lg">Entrar</button>
    </div>
  </form>
</div>

</body>
</html>
